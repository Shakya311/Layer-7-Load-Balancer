﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities
{
    public class FromBody
    {
        public int from { get; set; }

        public int to { get; set; }
    }
}
